import SwiftUI
import SpriteKit

struct ContentView: View {
    @State private var scene = GameScene(size: CGSize(width: 390, height: 700))

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            VStack(spacing: 12) {
                Text("贪吃蛇").font(.largeTitle.bold()).foregroundStyle(.green)
                SpriteView(scene: scene)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .clipShape(RoundedRectangle(cornerRadius: 18))
                    .gesture(DragGesture(minimumDistance: 12).onEnded { value in
                        let dx = value.translation.width
                        let dy = value.translation.height
                        if abs(dx) > abs(dy) {
                            scene.changeDirection(dx > 0 ? .right : .left)
                        } else {
                            scene.changeDirection(dy > 0 ? .down : .up)
                        }
                    })
                HStack {
                    Button("暂停 / 继续") { scene.togglePause() }
                    Button("重新开始") { scene.restart() }
                }
                .buttonStyle(.borderedProminent)
                .tint(.green)
                Text("滑动屏幕控制方向 · 撞墙或撞到自己即结束")
                    .font(.footnote).foregroundStyle(.white.opacity(0.7))
            }
            .padding()
        }
        .preferredColorScheme(.dark)
    }
}

final class GameScene: SKScene {
    enum Direction { case up, down, left, right }
    private var snake: [CGPoint] = []
    private var direction: Direction = .right
    private var nextDirection: Direction = .right
    private var food = CGPoint.zero
    private var score = 0
    private var best = UserDefaults.standard.integer(forKey: "snakeBest")
    private var tick: TimeInterval = 0
    private var step: TimeInterval = 0.16
    private var pausedGame = false
    private var ended = false
    private let cell: CGFloat = 20
    private var scoreLabel = SKLabelNode(fontNamed: "AvenirNext-Bold")
    private var messageLabel = SKLabelNode(fontNamed: "AvenirNext-Bold")

    override func didMove(to view: SKView) {
        backgroundColor = SKColor(red: 0.04, green: 0.07, blue: 0.05, alpha: 1)
        scaleMode = .resizeFill
        setup()
    }

    func setup() {
        removeAllChildren()
        score = 0; step = 0.16; ended = false; pausedGame = false
        direction = .right; nextDirection = .right
        let cols = max(8, Int(size.width / cell))
        let rows = max(12, Int((size.height - 70) / cell))
        let startX = CGFloat(cols / 2) * cell
        let startY = CGFloat(rows / 2) * cell
        snake = [CGPoint(x: startX, y: startY),
                 CGPoint(x: startX - cell, y: startY),
                 CGPoint(x: startX - 2 * cell, y: startY)]
        scoreLabel.fontSize = 20
        scoreLabel.fontColor = .white
        scoreLabel.horizontalAlignmentMode = .left
        scoreLabel.position = CGPoint(x: 14, y: size.height - 34)
        addChild(scoreLabel)
        messageLabel.fontSize = 22
        messageLabel.fontColor = .white
        messageLabel.position = CGPoint(x: size.width / 2, y: size.height / 2)
        addChild(messageLabel)
        spawnFood()
        updateBoard()
    }

    func changeDirection(_ d: Direction) {
        guard !ended else { return }
        switch (direction, d) {
        case (.up, .down), (.down, .up), (.left, .right), (.right, .left): return
        default: nextDirection = d
        }
    }

    func togglePause() {
        guard !ended else { return }
        pausedGame.toggle()
        messageLabel.text = pausedGame ? "已暂停" : ""
    }

    func restart() { setup() }

    override func update(_ currentTime: TimeInterval) {
        guard !pausedGame, !ended else { return }
        if tick == 0 { tick = currentTime }
        if currentTime - tick >= step {
            tick = currentTime
            move()
        }
    }

    private func move() {
        direction = nextDirection
        guard let head = snake.first else { return }
        var p = head
        switch direction {
        case .up: p.y += cell
        case .down: p.y -= cell
        case .left: p.x -= cell
        case .right: p.x += cell
        }
        let cols = max(8, Int(size.width / cell))
        let rows = max(12, Int((size.height - 70) / cell))
        let maxX = CGFloat(cols - 1) * cell
        let maxY = CGFloat(rows - 1) * cell
        if p.x < 0 || p.x > maxX || p.y < 0 || p.y > maxY || snake.dropLast().contains(p) {
            ended = true
            messageLabel.text = "游戏结束  ·  得分 \(score)"
            return
        }
        snake.insert(p, at: 0)
        if p == food {
            score += 1
            best = max(best, score)
            UserDefaults.standard.set(best, forKey: "snakeBest")
            step = max(0.07, step - 0.003)
            spawnFood()
        } else {
            snake.removeLast()
        }
        updateBoard()
    }

    private func spawnFood() {
        let cols = max(8, Int(size.width / cell))
        let rows = max(12, Int((size.height - 70) / cell))
        for _ in 0..<1000 {
            let p = CGPoint(x: CGFloat(Int.random(in: 0..<cols)) * cell,
                            y: CGFloat(Int.random(in: 0..<rows)) * cell)
            if !snake.contains(p) { food = p; return }
        }
    }

    private func updateBoard() {
        childNode(withName: "board")?.removeFromParent()
        let board = SKNode()
        board.name = "board"
        for (i, p) in snake.enumerated() {
            let node = SKShapeNode(rectOf: CGSize(width: cell - 2, height: cell - 2), cornerRadius: 4)
            node.fillColor = i == 0 ? .systemMint : .systemGreen
            node.strokeColor = .clear
            node.position = p
            board.addChild(node)
        }
        let f = SKShapeNode(circleOfRadius: cell * 0.38)
        f.fillColor = .systemRed; f.strokeColor = .clear; f.position = food
        board.addChild(f)
        addChild(board)
        scoreLabel.text = "分数：\(score)    最高：\(best)"
    }
}
