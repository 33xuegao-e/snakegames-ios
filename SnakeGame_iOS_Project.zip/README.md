# SnakeGame iOS

SwiftUI + SpriteKit 贪吃蛇游戏示例工程。

- 最低支持 iOS 16
- 滑动控制方向
- 吃食物增长并逐渐加速
- 撞墙或撞到自己时结束
- 暂停、继续、重新开始
- 本地保存最高分

使用 Xcode 打开 `SnakeGame.xcodeproj` 进行构建。签名信息请在构建平台的安全证书管理区配置，不要提交到仓库。
